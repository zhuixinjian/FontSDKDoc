# 混淆

混淆文件中加入以下语句
```
-keep public class com.xinmei365.fontsdk.**
-keep public class com.xinmei365.font.download.**
```
